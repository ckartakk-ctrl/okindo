// Supabase > Project Settings > API bölümünden alın
export const SUPABASE_URL = 'BURAYA_PROJECT_URL';
export const SUPABASE_KEY = 'BURAYA_ANON_PUBLIC_KEY';

// Seviyeye göre saatlik ücret (seviye 4 online uzman: seans başı)
export const UCRET = { 1: 180, 2: 250, 3: 300, 4: 350 };
export const KOMISYON = 0.2;   // yalnızca hizmet verenden
export const ACIL_FARK = 0.2;  // "Hemen" taleplerde eklenen fark

// Hizmet veren etiket sınırları (sunucuda da schema.sql içindeki tetikleyiciyle denetlenir)
export const SEKTOR_BASINA_EN_FAZLA = 10;
export const TOPLAM_EN_FAZLA = 40;

// Pilotta kapalı hizmetler (risk tablosu: "Çocuğu okuldan alma" 93 puan, çok yüksek bant).
// Açmak için listeden çıkarın; başka hizmet kapatmak için id ekleyin (id'ler data/hizmetler.json içinde).
export const PILOT_KAPALI = ['H0001'];
