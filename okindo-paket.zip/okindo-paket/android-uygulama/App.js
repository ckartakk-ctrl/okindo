import 'react-native-url-polyfill/auto';
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, SafeAreaView, Alert, StatusBar, BackHandler } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { SUPABASE_URL, SUPABASE_KEY, UCRET, KOMISYON, ACIL_FARK, SEKTOR_BASINA_EN_FAZLA, TOPLAM_EN_FAZLA, PILOT_KAPALI } from './config';
import HIZMETLER from './data/hizmetler.json';
import { Eslestirici, sektorler } from './lib/eslestirici';

const db = createClient(SUPABASE_URL, SUPABASE_KEY, { auth: { persistSession: false } });
const E = new Eslestirici(HIZMETLER);
const SEKTORLER = sektorler(HIZMETLER);
const HMAP = new Map(HIZMETLER.map(x => [x.id, x]));

const C = { bg: '#F3F7F6', sf: '#fff', ink: '#10243A', mut: '#566879', line: '#D9E4E1', br: '#13806F', soft: '#DDF1EB', amb: '#E8A12E', dg: '#C73E3E', dgs: '#FBE7E7' };
const fmt = n => '₺' + Number(n).toLocaleString('tr-TR');
const SEVIYE = {
  1: 'Kimlik doğrulandı (sıra, alışveriş, evrak gibi işler)',
  2: 'Adres ve referans doğrulandı (eve giriş, şoförlük gibi işler)',
  3: 'Adli sicil temiz (çocuk, yaşlı, hasta ile ilgili işler)',
  4: 'Uzman belgesi doğrulandı (veteriner, avukat, diyetisyen gibi)',
};
const EX = ['Annemi cuma günü hastaneye götürecek biri lazım', 'Tapuda benim yerime sıra bekleyecek biri lazım', 'Evde usta gelecek, ben işteyim', 'Köpeğimi akşam gezdirecek biri'];

/* ---------- küçük parçalar ---------- */
const Btn = ({ t, onPress, kind, disabled }) => (
  <TouchableOpacity disabled={disabled} onPress={onPress} style={[s.btn, kind === 'sec' && s.btnSec, kind === 'dg' && { backgroundColor: C.dg }, disabled && { opacity: 0.4 }]}>
    <Text style={[s.btnT, kind === 'sec' && { color: C.ink }]}>{t}</Text>
  </TouchableOpacity>
);
const Chip = ({ t, on, onPress }) => (
  <TouchableOpacity onPress={onPress} style={[s.chip, on && s.chipOn]}><Text style={{ fontWeight: '700', color: on ? C.br : C.ink }}>{t}</Text></TouchableOpacity>
);
const Card = ({ children, style }) => <View style={[s.card, style]}>{children}</View>;
const Head = ({ t, onBack }) => (
  <View style={s.head}>
    {onBack && <TouchableOpacity onPress={onBack} style={s.ib} accessibilityLabel="Geri"><Text style={s.ibT}>‹</Text></TouchableOpacity>}
    <Text style={[s.h1, { flex: 1 }]}>{t}</Text>
  </View>
);
const Rozet = ({ lv }) => <Text style={s.badge}>Seviye {lv}</Text>;

// Android geri tuşu: ana ekranda değilsek bir önceki ekrana dön
function useGeri(fn) {
  useEffect(() => {
    if (!fn) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => { fn(); return true; });
    return () => sub.remove();
  }, [fn]);
}

export default function App() {
  const [uid, setUid] = useState(null);
  const [role, setRole] = useState('al');
  useEffect(() => {
    (async () => {
      let id = await AsyncStorage.getItem('okindo-uid');
      if (!id) { id = 'u' + Math.random().toString(36).slice(2, 10); await AsyncStorage.setItem('okindo-uid', id); }
      setUid(id);
    })();
  }, []);
  if (!uid) return null;
  return (
    <SafeAreaView style={s.root}>
      <StatusBar barStyle="dark-content" backgroundColor={C.bg} />
      <View style={s.top}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <View style={s.logoBox}><Text style={{ color: '#fff', fontWeight: '800', fontSize: 16 }}>✓</Text></View>
          <Text style={s.logo}>okindo</Text>
        </View>
        <View style={s.seg}>
          {[['al', 'Hizmet al'], ['ver', 'Hizmet ver']].map(([r, l]) => (
            <TouchableOpacity key={r} onPress={() => setRole(r)} style={[s.segB, role === r && { backgroundColor: C.br }]}>
              <Text style={{ fontWeight: '700', color: role === r ? '#fff' : C.mut }}>{l}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
      {role === 'al' ? <Customer uid={uid} /> : <Provider uid={uid} />}
    </SafeAreaView>
  );
}

/* ---------- ortak: sektör ve hizmet gezgini ---------- */
function Gezgin({ secili, onSec, ust, sek, setSek }) {
  // secili: Set (hizmet veren için işaretli id'ler) ya da null (müşteri için)
  // sek/setSek üst bileşende tutulur ki Android geri tuşu önce sektör listesini kapatsın
  const [ara, setAra] = useState('');
  const bul = useMemo(() => (ara.trim().length >= 3 ? E.tahmin(ara, 8).hizmetler : []), [ara]);

  const Satir = ({ x }) => {
    const on = secili && secili.has(x.id);
    const kilit = ust && x.seviye > ust;
    return (
      <TouchableOpacity onPress={() => onSec(x)} style={[s.row, { flexDirection: 'row', alignItems: 'center', gap: 12 }]}>
        {secili && <View style={[s.box, on && { backgroundColor: C.br, borderColor: C.br }]}>{on && <Text style={{ color: '#fff', fontWeight: '800' }}>✓</Text>}</View>}
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, color: C.ink }}>{x.hizmet}</Text>
          <Text style={[s.mut, { fontSize: 13 }]}>
            Seviye {x.seviye}{kilit ? ' · onay gelince görünür' : ''}{PILOT_KAPALI.includes(x.id) ? ' · pilotta kapalı' : ''}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  if (sek) {
    const liste = SEKTORLER.find(x => x.ad === sek).liste;
    return (
      <View style={{ gap: 4 }}>
        <Head t={sek} onBack={() => setSek(null)} />
        {liste.map(x => <Satir key={x.id} x={x} />)}
      </View>
    );
  }
  return (
    <View style={{ gap: 10 }}>
      <TextInput style={s.fld} value={ara} onChangeText={setAra} placeholder="Ara: örn. köpek gezdirme" placeholderTextColor={C.mut} />
      {bul.map(x => <Satir key={x.id} x={x} />)}
      {ara.trim().length >= 3 && !bul.length && <Text style={s.mut}>Eşleşen hizmet yok. Sektörlerden bakın.</Text>}
      <Text style={s.h2}>Sektörler</Text>
      {SEKTORLER.map(({ ad, liste }) => {
        const n = secili ? liste.filter(x => secili.has(x.id)).length : 0;
        return (
          <TouchableOpacity key={ad} onPress={() => setSek(ad)} style={[s.row, { flexDirection: 'row', justifyContent: 'space-between' }]}>
            <Text style={{ fontSize: 16, color: C.ink, flex: 1 }}>{ad}</Text>
            <Text style={{ color: n ? C.br : C.mut, fontWeight: n ? '800' : '500' }}>{n ? `${n} seçili` : liste.length}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

/* ---------------- MÜŞTERİ ---------------- */
function Customer({ uid }) {
  const [scr, setScr] = useState('home');
  const [text, setText] = useState('');
  const [aday, setAday] = useState([]);
  const [svc, setSvc] = useState(null);
  const [kisi, setKisi] = useState(null); // bu hizmeti yapan onaylı kişi sayısı
  const [hrs, setHrs] = useState(3);
  const [who, setWho] = useState('Kendim');
  const [when, setWhen] = useState('Hemen');
  const [pay, setPay] = useState('Kart');
  const [req, setReq] = useState(null);
  const [stars, setStars] = useState(0);
  const [note, setNote] = useState('');

  const online = svc && svc.seviye === 4;
  const birim = online ? 'seans' : 'saat';
  const taban = svc ? UCRET[svc.seviye] * hrs : 0;
  const acil = when === 'Hemen' ? Math.round(taban * ACIL_FARK) : 0;
  const total = taban + acil;
  const kapali = svc && PILOT_KAPALI.includes(svc.id);

  const [sek, setSek] = useState(null);
  const geri = { pick: 'home', list: 'home', conf: aday.length ? 'pick' : 'list', rate: 'track' }[scr];
  useGeri(scr === 'list' && sek ? () => setSek(null) : geri ? () => setScr(geri) : null);

  // Açık işi geri yükle + 3 sn'de bir güncelle
  const load = useCallback(async () => {
    const { data } = await db.from('requests').select('*').eq('customer', uid).neq('status', 'rated').order('created_at', { ascending: false }).limit(1);
    if (data && data[0]) { setReq(data[0]); setScr(p => (p === 'home' || p === 'track' ? 'track' : p)); }
    else { setReq(null); setScr(p => (p === 'track' ? 'home' : p)); }
  }, [uid]);
  useEffect(() => { load(); const i = setInterval(load, 3000); return () => clearInterval(i); }, [load]);

  const bul = async () => {
    const r = E.tahmin(text, 3);
    setAday(r.hizmetler);
    if (!r.hizmetler.length) {
      db.from('unmatched_queries').insert({ text }).then(() => {});
      setScr('list');
    } else setScr('pick');
  };
  const sec = async x => {
    setSvc(x); setHrs(x.seviye === 4 ? 1 : 3); setScr('conf'); setKisi(null);
    const { data } = await db.from('provider_services').select('provider_id, providers!inner(approved_level)').eq('service_id', x.id).gte('providers.approved_level', x.seviye);
    setKisi(data ? data.length : 0);
  };
  const book = async () => {
    const { data, error } = await db.from('requests').insert({
      customer: uid, service: svc.hizmet, service_id: svc.id, sector: svc.sektor, level: svc.seviye,
      detail: `${who} için. ${text}`.trim(), hours: hrs, total, commission: Math.round(total * KOMISYON),
      pay, code: String(Math.floor(1000 + Math.random() * 9000)),
    }).select().single();
    if (error) return Alert.alert('Hata', error.message);
    setReq(data); setScr('track');
  };
  const cancel = async () => { await db.from('requests').delete().eq('id', req.id).eq('status', 'open'); setReq(null); setScr('home'); };
  const send = async () => {
    await db.from('requests').update({ stars, note, status: 'rated' }).eq('id', req.id);
    setReq(null); setStars(0); setNote(''); setText(''); setScr('home');
    Alert.alert('Teşekkürler', 'Puanınız kaydedildi.');
  };
  const minLen = stars === 4 ? 10 : 50;
  const canSend = stars && (stars === 5 || note.length >= minLen);

  if (scr === 'home') return (
    <ScrollView contentContainerStyle={s.pad} keyboardShouldPersistTaps="handled">
      <Text style={s.h1}>Ne yardım lazım?</Text>
      <Text style={s.mut}>Kendi cümlenizle yazın, doğrulanmış biri yanınızda olsun.</Text>
      <TextInput style={s.ask} multiline value={text} onChangeText={setText} placeholder="Örnek: Annemi cuma günü hastaneye götürecek biri lazım" placeholderTextColor={C.mut} />
      <Btn t="Kişi bul" disabled={text.trim().length < 3} onPress={bul} />
      <TouchableOpacity onPress={() => { setAday([]); setScr('list'); }} style={{ alignSelf: 'center', padding: 8 }}>
        <Text style={{ color: C.br, fontWeight: '800' }}>Listeden seçmek istiyorum</Text>
      </TouchableOpacity>
      <Text style={s.h2}>Sık istenenler</Text>
      {EX.map(x => <TouchableOpacity key={x} onPress={() => setText(x)} style={s.row}><Text style={{ fontSize: 17, color: C.ink }}>{x}</Text></TouchableOpacity>)}
    </ScrollView>
  );

  if (scr === 'pick') return (
    <ScrollView contentContainerStyle={s.pad}>
      <Head t="Bunlardan hangisi?" onBack={() => setScr('home')} />
      <Text style={s.mut}>“{text.trim()}”</Text>
      {aday.map((x, i) => (
        <TouchableOpacity key={x.id} onPress={() => sec(x)} style={[s.card, i === 0 && { borderColor: C.br, backgroundColor: C.soft }]}>
          <Text style={s.big}>{x.hizmet}</Text>
          <Text style={s.mut}>{x.sektor}</Text>
          <Rozet lv={x.seviye} />
        </TouchableOpacity>
      ))}
      <Btn kind="sec" t="Hiçbiri, listeden seçeceğim" onPress={() => { db.from('unmatched_queries').insert({ text }).then(() => {}); setScr('list'); }} />
    </ScrollView>
  );

  if (scr === 'list') return (
    <ScrollView contentContainerStyle={s.pad} keyboardShouldPersistTaps="handled">
      <Head t="Hizmet seçin" onBack={() => setScr('home')} />
      {text.trim().length >= 3 && <Text style={s.mut}>Yazdığınızı tam anlayamadık. Aşağıdan seçebilirsiniz; cümleniz sözlüğü geliştirmek için kaydedildi.</Text>}
      <Gezgin secili={null} onSec={sec} sek={sek} setSek={setSek} />
    </ScrollView>
  );

  if (scr === 'conf' && svc) return (
    <ScrollView contentContainerStyle={s.pad}>
      <Head t="Sizi şöyle anladık" onBack={() => setScr(aday.length ? 'pick' : 'list')} />
      <Card style={{ backgroundColor: C.soft, borderColor: C.br }}>
        <Text style={s.mut}>{svc.sektor}</Text>
        <Text style={s.big}>{svc.hizmet}</Text>
        <Rozet lv={svc.seviye} />
        <Text style={s.mut}>{SEVIYE[svc.seviye]}</Text>
        <Text style={{ fontWeight: '700', color: C.ink }}>
          {kisi === null ? 'Uygun kişiler aranıyor…' : kisi ? `Bu işi yapan ${kisi} onaylı kişi var.` : 'Bu iş için henüz onaylı kişi yok. Talebiniz kaydedilir, kişi katılınca görünür.'}
        </Text>
      </Card>
      {kapali ? (
        <Card style={{ borderColor: C.dg, backgroundColor: C.dgs }}>
          <Text style={{ fontWeight: '800', color: C.ink }}>Bu hizmet pilot döneminde henüz açık değil.</Text>
          <Text style={s.mut}>Güvenlik kontrolleri tamamlanınca açılacak.</Text>
        </Card>
      ) : (<>
        <Text style={s.h2}>Kimin için?</Text>
        <View style={s.chips}>{['Kendim', 'Annem', 'Babam', 'Başkası'].map(x => <Chip key={x} t={x} on={who === x} onPress={() => setWho(x)} />)}</View>
        <Text style={s.h2}>Ne zaman?</Text>
        <View style={s.chips}>{['Hemen', 'Planlı'].map(x => <Chip key={x} t={x} on={when === x} onPress={() => setWhen(x)} />)}</View>
        {!online && (<>
          <Text style={s.h2}>Süre</Text>
          <View style={s.step}>
            <TouchableOpacity style={s.ib} onPress={() => setHrs(Math.max(1, hrs - 1))}><Text style={s.ibT}>−</Text></TouchableOpacity>
            <Text style={s.big}>{hrs} saat</Text>
            <TouchableOpacity style={s.ib} onPress={() => setHrs(Math.min(12, hrs + 1))}><Text style={s.ibT}>+</Text></TouchableOpacity>
          </View>
        </>)}
        <Text style={s.h2}>Ödeme iş bitince</Text>
        <View style={s.chips}>{['Kart', 'Nakit'].map(x => <Chip key={x} t={x} on={pay === x} onPress={() => setPay(x)} />)}</View>
        <Text style={s.mut}>{pay === 'Kart' ? 'Kart ödemesi bu pilot sürümde gerçek çekilmez.' : 'Tutarı iş bitince elden ödersiniz.'}</Text>
        <View style={{ gap: 6 }}>
          <View style={s.line}><Text>{fmt(UCRET[svc.seviye])} × {hrs} {birim}</Text><Text>{fmt(taban)}</Text></View>
          {acil > 0 && <View style={s.line}><Text>Acil talep farkı</Text><Text>{fmt(acil)}</Text></View>}
        </View>
        <View style={s.sum}><Text style={{ fontSize: 19 }}>Toplam</Text><Text style={s.big}>{fmt(total)}</Text></View>
        <Btn t="Onayla ve çağır" onPress={book} />
      </>)}
    </ScrollView>
  );

  if (scr === 'track' && req) {
    const st = { open: 'Size uygun kişi aranıyor…', accepted: 'Hizmet veren yola çıktı', started: 'Hizmet başladı', done: 'İş tamamlandı' }[req.status];
    return (
      <ScrollView contentContainerStyle={s.pad}>
        <Text style={s.h1}>Canlı takip</Text>
        <Card style={{ backgroundColor: C.soft, borderColor: C.br }}>
          <Text style={s.big}>{req.service}</Text>
          <Text style={s.mut}>{req.sector ? req.sector + ' · ' : ''}{fmt(req.total)} · {req.pay}</Text>
          <Text style={{ fontWeight: '800', fontSize: 18, color: C.br }}>{st}</Text>
        </Card>
        {req.status === 'accepted' && (
          <Card><Text style={s.mut}>Kapıda doğrulama kodu. Gelen kişi bu kodu söylemeli:</Text><Text style={[s.big, { fontSize: 40, letterSpacing: 8 }]}>{req.code}</Text></Card>
        )}
        {req.status === 'open' && <Btn kind="sec" t="Talebi iptal et" onPress={cancel} />}
        {req.status === 'done' && <Btn t="Puan ver" onPress={() => setScr('rate')} />}
        <Btn kind="dg" t="Acil durum (pilot)" onPress={() => Alert.alert('Acil durum', 'Tam sürümde konumunuz yakınlarınıza ve ekibe gider. Şimdilik 112\'yi arayın.')} />
      </ScrollView>
    );
  }

  if (scr === 'rate') return (
    <ScrollView contentContainerStyle={s.pad}>
      <Text style={s.h1}>Nasıl geçti?</Text>
      <View style={s.stars}>{[1, 2, 3, 4, 5].map(n => (
        <TouchableOpacity key={n} onPress={() => { setStars(n); setNote(''); }} style={[s.star, stars === n && { borderColor: C.amb }]}><Text style={{ fontSize: 28, color: C.amb }}>{n <= stars ? '★' : '☆'}</Text></TouchableOpacity>
      ))}</View>
      {stars > 0 && stars < 5 && (<>
        <Text>{stars === 4 ? 'Neyi eksikti? Kısaca yazın.' : 'Ne yaşandığını anlatın (en az 50 karakter).'}</Text>
        <TextInput style={[s.ask, { minHeight: 100 }]} multiline value={note} onChangeText={setNote} />
        <Text style={s.mut}>{note.length}/{minLen}</Text>
      </>)}
      <Btn t="Gönder" disabled={!canSend} onPress={send} />
    </ScrollView>
  );
  return null;
}

/* ---------------- HİZMET VEREN ---------------- */
function Provider({ uid }) {
  const [me, setMe] = useState(undefined); // undefined: yükleniyor, null: kayıtlı değil
  const [scr, setScr] = useState('panel');
  const [tags, setTags] = useState(new Set());
  const [bal, setBal] = useState(0);
  const [open, setOpen] = useState([]);
  const [mine, setMine] = useState(null);
  const [code, setCode] = useState('');
  const [stats, setStats] = useState([]);
  // kayıt formu
  const [ad, setAd] = useState('');
  const [tel, setTel] = useState('');
  const [beyan, setBeyan] = useState(1);
  // kelime önerisi
  const [oneri, setOneri] = useState({ id: null, k: '' });

  const [sek, setSek] = useState(null);
  useGeri(scr === 'etiket' && sek ? () => setSek(null) : scr !== 'panel' && me ? () => setScr('panel') : null);

  const loadMe = useCallback(async () => {
    const { data } = await db.from('providers').select('*').eq('id', uid).maybeSingle();
    setMe(data || null);
    if (data) {
      const { data: t } = await db.from('provider_services').select('service_id').eq('provider_id', uid);
      setTags(new Set((t || []).map(x => x.service_id)));
    }
  }, [uid]);
  useEffect(() => { loadMe(); }, [loadMe]);

  const load = useCallback(async () => {
    if (!me) return;
    let { data: w } = await db.from('wallets').select('*').eq('id', uid).maybeSingle();
    if (!w) { await db.from('wallets').insert({ id: uid, balance: 0 }); w = { balance: 0 }; }
    setBal(w.balance);
    const { data: m } = await db.from('requests').select('*').eq('provider', uid).in('status', ['accepted', 'started']).limit(1);
    setMine(m && m[0] ? m[0] : null);
    const ids = [...tags];
    if (ids.length) {
      const { data: o } = await db.from('requests').select('*').eq('status', 'open').in('service_id', ids).order('created_at').limit(20);
      setOpen(o || []);
    } else setOpen([]);
    const { data: st } = await db.from('provider_service_stats').select('*').eq('provider_id', uid);
    setStats(st || []);
  }, [uid, me, tags]);
  useEffect(() => { load(); const i = setInterval(load, 3000); return () => clearInterval(i); }, [load]);

  const kaydol = async () => {
    const { error } = await db.from('providers').insert({ id: uid, name: ad.trim(), phone: tel.trim(), declared_level: beyan });
    if (error) return Alert.alert('Hata', error.message);
    await loadMe(); setScr('etiket');
  };

  const toggle = async x => {
    const varmi = tags.has(x.id);
    if (varmi) {
      await db.from('provider_services').delete().eq('provider_id', uid).eq('service_id', x.id);
      const n = new Set(tags); n.delete(x.id); setTags(n); return;
    }
    const sektorde = HIZMETLER.filter(h => h.sektor === x.sektor && tags.has(h.id)).length;
    if (sektorde >= SEKTOR_BASINA_EN_FAZLA) return Alert.alert('Sınır', `Bir sektörde en fazla ${SEKTOR_BASINA_EN_FAZLA} hizmet seçebilirsiniz.`);
    if (tags.size >= TOPLAM_EN_FAZLA) return Alert.alert('Sınır', `Toplam en fazla ${TOPLAM_EN_FAZLA} hizmet seçebilirsiniz.`);
    const { error } = await db.from('provider_services').insert({ provider_id: uid, service_id: x.id, sector: x.sektor });
    if (error) return Alert.alert('Kaydedilemedi', error.message);
    const n = new Set(tags); n.add(x.id); setTags(n);
    if (x.seviye > me.approved_level) Alert.alert('Kaydedildi', `Bu iş seviye ${x.seviye} gerektiriyor. Onayınız gelene kadar size bu işten teklif gelmez.`);
  };

  const kelimeGonder = async () => {
    const k = oneri.k.trim();
    if (k.length < 2) return;
    await db.from('keyword_suggestions').insert({ provider_id: uid, service_id: oneri.id, keyword: k });
    setOneri({ id: null, k: '' });
    Alert.alert('Teşekkürler', 'Öneriniz incelendikten sonra eklenecek.');
  };

  const accept = async r => {
    const { data, error } = await db.rpc('accept_request', { p_request: r.id, p_provider: uid });
    if (error) return Alert.alert('Hata', error.message);
    const m = { alindi: 'Bu işi başka biri aldı.', seviye: `Bu iş seviye ${r.level} onayı gerektiriyor.`, etiket: 'Bu hizmet etiketlerinizde yok.', bakiye: 'Bakiyeniz eksi. Önce bakiyenizi kapatın.', kayit: 'Önce kaydınızı tamamlayın.' }[data];
    if (m) Alert.alert('Kabul edilemedi', m);
    load();
  };
  const start = async () => {
    if (code !== mine.code) return Alert.alert('Kod yanlış', 'Müşterinin söylediği 4 haneli kodu girin.');
    await db.from('requests').update({ status: 'started' }).eq('id', mine.id); setCode(''); load();
  };
  const finish = async () => {
    await db.from('requests').update({ status: 'done' }).eq('id', mine.id);
    if (mine.pay === 'Nakit') await db.from('wallets').update({ balance: bal - mine.commission }).eq('id', uid);
    load();
  };
  const closeBal = async () => { await db.from('wallets').update({ balance: 0 }).eq('id', uid); load(); Alert.alert('Bakiye kapandı', 'Tam sürümde burada ödeme alınır.'); };

  if (me === undefined) return <View style={s.pad}><Text style={s.mut}>Yükleniyor…</Text></View>;

  /* kayıt */
  if (me === null) return (
    <ScrollView contentContainerStyle={s.pad} keyboardShouldPersistTaps="handled">
      <Text style={s.h1}>Hizmet veren ol</Text>
      <Text style={s.mut}>Önce kendinizi tanıtın, sonra hangi işleri yaptığınızı kendiniz seçin.</Text>
      <TextInput style={s.fld} value={ad} onChangeText={setAd} placeholder="Adınız soyadınız" placeholderTextColor={C.mut} />
      <TextInput style={s.fld} value={tel} onChangeText={setTel} placeholder="Telefon" keyboardType="phone-pad" placeholderTextColor={C.mut} />
      <Text style={s.h2}>Hangi doğrulamayı yaptırabilirsiniz?</Text>
      {[1, 2, 3, 4].map(n => (
        <TouchableOpacity key={n} onPress={() => setBeyan(n)} style={[s.card, beyan === n && { borderColor: C.br, backgroundColor: C.soft }]}>
          <Text style={{ fontWeight: '800', color: C.ink }}>Seviye {n}</Text>
          <Text style={s.mut}>{SEVIYE[n]}</Text>
        </TouchableOpacity>
      ))}
      <Text style={s.mut}>Belgeleriniz kontrol edilene kadar onaylı seviyeniz 1 kalır. Yüksek seviyeli işleri şimdiden seçebilirsiniz, onay gelince teklif almaya başlarsınız.</Text>
      <Btn t="Kaydol ve işlerimi seç" disabled={ad.trim().length < 3 || tel.trim().length < 10} onPress={kaydol} />
    </ScrollView>
  );

  /* etiket seçimi */
  if (scr === 'etiket') return (
    <ScrollView contentContainerStyle={s.pad} keyboardShouldPersistTaps="handled">
      <Head t="Yaptığım işler" onBack={() => setScr('panel')} />
      <Text style={s.mut}>{tags.size}/{TOPLAM_EN_FAZLA} seçili · sektör başına en fazla {SEKTOR_BASINA_EN_FAZLA}. Sadece işaretlediğiniz işlerden teklif alırsınız.</Text>
      <Gezgin secili={tags} onSec={toggle} ust={me.approved_level} sek={sek} setSek={setSek} />
    </ScrollView>
  );

  /* seçili etiketler ve kelime önerisi */
  if (scr === 'liste') {
    const sec = [...tags].map(id => HMAP.get(id)).filter(Boolean);
    return (
      <ScrollView contentContainerStyle={s.pad} keyboardShouldPersistTaps="handled">
        <Head t="Etiketlerim" onBack={() => setScr('panel')} />
        <Text style={s.mut}>Müşteriler bu işi farklı kelimelerle arıyorsa önerin; onaydan sonra arama bunu da tanır.</Text>
        {sec.map(x => {
          const st = stats.find(y => y.service_id === x.id);
          return (
            <Card key={x.id}>
              <Text style={{ fontWeight: '800', color: C.ink }}>{x.hizmet}</Text>
              <Text style={s.mut}>{x.sektor} · Seviye {x.seviye}{x.seviye > me.approved_level ? ' · onay bekliyor' : ''}{st ? ` · ${st.avg_stars} puan, ${st.jobs} iş` : ''}</Text>
              {oneri.id === x.id ? (<>
                <TextInput style={s.fld} value={oneri.k} onChangeText={k => setOneri({ id: x.id, k })} placeholder="Örn: kapıda bekleme" placeholderTextColor={C.mut} autoFocus />
                <View style={{ flexDirection: 'row', gap: 10 }}>
                  <View style={{ flex: 1 }}><Btn kind="sec" t="Vazgeç" onPress={() => setOneri({ id: null, k: '' })} /></View>
                  <View style={{ flex: 1 }}><Btn t="Gönder" onPress={kelimeGonder} /></View>
                </View>
              </>) : (
                <TouchableOpacity onPress={() => setOneri({ id: x.id, k: '' })}><Text style={{ color: C.br, fontWeight: '800' }}>Kelime öner</Text></TouchableOpacity>
              )}
            </Card>
          );
        })}
        <Btn kind="sec" t="İş ekle / çıkar" onPress={() => setScr('etiket')} />
      </ScrollView>
    );
  }

  /* panel */
  const neg = bal < 0;
  return (
    <ScrollView contentContainerStyle={s.pad}>
      <Text style={s.h1}>İyi günler{me.name ? ', ' + me.name.split(' ')[0] : ''}</Text>
      <Card>
        <Text style={s.mut}>Onaylı seviye</Text>
        <Text style={s.big}>Seviye {me.approved_level}</Text>
        {me.declared_level > me.approved_level && <Text style={s.mut}>Seviye {me.declared_level} için belge kontrolü bekleniyor.</Text>}
      </Card>
      <TouchableOpacity onPress={() => setScr(tags.size ? 'liste' : 'etiket')} style={[s.card, !tags.size && { borderColor: C.amb }]}>
        <Text style={s.mut}>Yaptığım işler</Text>
        <Text style={s.big}>{tags.size ? `${tags.size} hizmet` : 'Henüz seçilmedi'}</Text>
        <Text style={{ color: C.br, fontWeight: '800' }}>{tags.size ? 'Etiketlerimi gör' : 'İşlerimi seç'}</Text>
      </TouchableOpacity>
      <Card style={neg && { borderColor: C.dg, backgroundColor: C.dgs }}>
        <Text style={s.mut}>Komisyon bakiyesi</Text>
        <Text style={s.big}>{neg ? '−' : ''}{fmt(Math.abs(bal))}</Text>
        {neg ? (<><Text>Yeni iş almak için bakiyenizi kapatın.</Text><Btn kind="sec" t="Bakiyeyi kapat (pilot)" onPress={closeBal} /></>) : <Text style={s.mut}>Yeni işler açık.</Text>}
      </Card>
      {mine ? (
        <Card style={{ backgroundColor: C.soft, borderColor: C.br }}>
          <Text style={s.big}>{mine.service}</Text>
          <Text>{fmt(mine.total)} · {mine.pay}{mine.pay === 'Nakit' ? ` · komisyon ${fmt(mine.commission)}` : ''}</Text>
          {mine.detail ? <Text style={s.mut}>{mine.detail}</Text> : null}
          {mine.status === 'accepted' ? (<>
            <Text style={s.mut}>Müşterinin söylediği kodu girin:</Text>
            <TextInput style={s.ask} keyboardType="number-pad" maxLength={4} value={code} onChangeText={setCode} placeholder="0000" />
            <Btn t="İşe başla" onPress={start} />
          </>) : <Btn t="İşi bitir" onPress={finish} />}
        </Card>
      ) : !tags.size ? null : open.length === 0 ? (
        <Card><Text style={s.big}>Bekleyen teklif yok</Text><Text style={s.mut}>Seçtiğiniz işlerden talep gelince burada görünür.</Text></Card>
      ) : open.map(r => {
        const kilit = (r.level || 1) > me.approved_level;
        return (
          <Card key={r.id}>
            <Text style={s.big}>Yeni iş teklifi</Text>
            <Text>{r.service} · {r.hours} {r.level === 4 ? 'seans' : 'saat'}</Text>
            <Text style={s.mut}>Ödeme: {r.pay} {fmt(r.total)} · Komisyon {fmt(r.commission)}</Text>
            {kilit && <Text style={{ color: C.dg }}>Bu iş seviye {r.level} onayı gerektiriyor.</Text>}
            {neg && <Text style={{ color: C.dg }}>Bakiyeniz eksi olduğu için kabul edemezsiniz.</Text>}
            <Btn t="Kabul et" disabled={neg || kilit} onPress={() => accept(r)} />
          </Card>
        );
      })}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 10 },
  logoBox: { width: 28, height: 28, borderRadius: 9, backgroundColor: C.br, alignItems: 'center', justifyContent: 'center' },
  logo: { fontSize: 22, fontWeight: '800', color: C.ink },
  seg: { flexDirection: 'row', backgroundColor: C.sf, borderRadius: 99, borderWidth: 1, borderColor: C.line, padding: 4 },
  segB: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 99 },
  pad: { padding: 20, gap: 14, paddingBottom: 60 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  h1: { fontSize: 28, fontWeight: '800', color: C.ink },
  h2: { fontSize: 17, fontWeight: '800', color: C.ink, marginTop: 6 },
  mut: { color: C.mut, fontSize: 15 },
  big: { fontSize: 22, fontWeight: '800', color: C.ink },
  badge: { alignSelf: 'flex-start', backgroundColor: C.br, color: '#fff', fontSize: 13, fontWeight: '700', paddingVertical: 4, paddingHorizontal: 10, borderRadius: 99, overflow: 'hidden' },
  ask: { backgroundColor: C.sf, borderWidth: 2, borderColor: C.ink, borderRadius: 22, padding: 16, fontSize: 19, minHeight: 80, textAlignVertical: 'top', color: C.ink },
  fld: { backgroundColor: C.sf, borderWidth: 1.5, borderColor: C.line, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 12, fontSize: 17, color: C.ink },
  btn: { minHeight: 56, borderRadius: 18, backgroundColor: C.br, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 20 },
  btnSec: { backgroundColor: C.sf, borderWidth: 1.5, borderColor: C.line },
  btnT: { color: '#fff', fontSize: 18, fontWeight: '800' },
  card: { backgroundColor: C.sf, borderWidth: 1, borderColor: C.line, borderRadius: 22, padding: 18, gap: 8 },
  row: { borderTopWidth: 1, borderColor: C.line, paddingVertical: 13 },
  box: { width: 26, height: 26, borderRadius: 8, borderWidth: 2, borderColor: C.line, alignItems: 'center', justifyContent: 'center' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { borderWidth: 1.5, borderColor: C.line, backgroundColor: C.sf, borderRadius: 99, paddingVertical: 11, paddingHorizontal: 18 },
  chipOn: { backgroundColor: C.soft, borderColor: C.br },
  step: { flexDirection: 'row', alignItems: 'center', gap: 18 },
  ib: { width: 46, height: 46, borderRadius: 23, borderWidth: 1.5, borderColor: C.line, backgroundColor: C.sf, alignItems: 'center', justifyContent: 'center' },
  ibT: { fontSize: 26, fontWeight: '700', color: C.ink },
  line: { flexDirection: 'row', justifyContent: 'space-between' },
  sum: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', borderTopWidth: 2, borderColor: C.ink, paddingTop: 12 },
  stars: { flexDirection: 'row', gap: 6 },
  star: { flex: 1, height: 58, borderRadius: 16, borderWidth: 1.5, borderColor: C.line, backgroundColor: C.sf, alignItems: 'center', justifyContent: 'center' },
});
