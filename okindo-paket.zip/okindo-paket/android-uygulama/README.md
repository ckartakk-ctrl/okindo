# Okindo Android uygulaması (pilot, sürüm 0.2)

## Bu sürümde neler var

- **Müşteri** kendi cümlesiyle yazar ("annemi hastaneye götürecek biri"). Uygulama yapay zeka kullanmadan, kelime eşleştirmeyle 2.648 hizmet ve 50 sektör içinden en uygun 3 hizmeti önerir. Müşteri doğru olanı seçer. Hiçbiri uymazsa listeden seçer; cümlesi sözlüğü geliştirmek için kaydedilir.
- **Hizmet veren** kayıt olur, sonra hangi işleri yaptığını kendisi işaretler (sektör başına en fazla 10, toplam en fazla 40). Sadece işaretlediği işlerden teklif alır.
- **Seviye kilidi:** Herkesin onaylı seviyesi 1 başlar. Yüksek seviyeli işleri şimdiden seçebilir ama onay gelene kadar o işlerden teklif alamaz. Kontrol sunucuda yapılır, uygulama atlatamaz.
- **Kelime önerisi:** Hizmet veren, müşterilerin bir işi farklı kelimelerle aradığını düşünüyorsa öneri gönderir; siz onaylarsınız.
- **Puan hizmet bazında** tutulur: aynı kişinin şoförlükteki puanı ile hastane eşliğindeki puanı ayrıdır.
- Pilotta kapalı hizmet: "Okuldan alma ve eve bırakma" (risk puanı 93). `config.js` içinden açılıp kapatılır.
- Önceki sürümdeki akış korunur: talep, kabul, kapıda 4 haneli kod, işi bitirme, puan, nakit işlerde komisyonun eksi bakiyeye yazılması.

## 1) Veritabanı (Supabase, ücretsiz hesap yeterli)
1. supabase.com'da yeni proje açın.
2. SQL Editor'e `schema.sql` içeriğini yapıştırıp çalıştırın. (Önceki sürümü kurduysanız yine çalıştırın, eksikleri ekler.)
3. Project Settings > API bölümündeki URL ve anon key'i `config.js` içine yazın.

## 2) Bilgisayarda hazırlık
1. nodejs.org'dan Node.js LTS sürümünü kurun.
2. Terminalde:
```
npx create-expo-app okindo --template blank
cd okindo
```
3. Bu klasördeki şunları `okindo` klasörünün içine kopyalayın, sorarsa üzerine yazın: `App.js`, `config.js`, `app.json`, `eas.json`, `lib/`, `data/`, `assets/`.
4. Gerekli paketler:
```
npx expo install @supabase/supabase-js @react-native-async-storage/async-storage react-native-url-polyfill
```

## 3) Hızlı deneme (APK'sız)
```
npx expo start
```
Android telefona Play Store'dan **Expo Go** kurun, ekrandaki QR kodu okutun.

## 4) Android APK (telefona kurulan dosya)
Android Studio gerekmez; derleme Expo'nun sunucularında yapılır.
```
npm install -g eas-cli
eas login            (expo.dev'de ücretsiz hesap)
eas build -p android --profile preview
```
Bitince bir indirme bağlantısı verir. APK'yı telefonda açın; telefon "bilinmeyen kaynak" izni isterse verin. Bu APK'yı pilot kullanıcılara doğrudan gönderebilirsiniz.

## 5) Google Play'e yükleme (sonraki adım)
```
eas build -p android --profile production
```
Bu, Play Store'un istediği `.aab` dosyasını üretir. Yüklemek için Google Play Console'da geliştirici hesabı (tek seferlik ücretli) gerekir. `app.json` içindeki `com.okindo.app` paket adı Play'de benzersiz olmalı; alınmışsa değiştirin.

## Yönetim (Supabase panelinden)
- **Seviye onayı:** Table Editor > `providers`. Kimlik ve sicil kontrolü bitince kişinin `approved_level` değerini yükseltin. Uygulama bu alanı değiştiremez.
- **Kelime önerileri:** `keyword_suggestions` tablosu. Uygun bulduklarınızı `data/hizmetler.json` içindeki ilgili hizmetin `anahtar` listesine ekleyin; bir sonraki derlemede geçerli olur.
- **Anlaşılamayan cümleler:** `unmatched_queries` tablosu. Sık gelenleri sözlüğe kelime ya da yeni hizmet olarak ekleyin.
- **Hizmet puanları:** `provider_service_stats` görünümü.

## Henüz sahte / eksik
Giriş sistemi (cihaz kimliği kullanılıyor), gerçek kart ödemesi, TC ve adli sicil doğrulamasının uygulama içinden yapılması, bildirim, harita, mesajlaşma, acil durum düğmesinin gerçek çalışması. `schema.sql` içindeki açık izinler yalnızca pilot içindir; gerçek kullanıma geçmeden giriş sistemi ve kişiye özel kurallar eklenmelidir.
