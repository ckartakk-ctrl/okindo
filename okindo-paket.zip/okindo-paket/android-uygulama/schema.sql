-- Okindo pilot veritabanı. Supabase > SQL Editor'e yapıştırıp bir kez çalıştırın.
-- Önceki sürümü kurduysanız da güvenle çalıştırılabilir (eksik tablo ve sütunları ekler).

-- 1) Talepler
create table if not exists requests(
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  customer text not null,
  provider text,
  service text not null,
  detail text,
  hours int not null,
  total int not null,
  commission int not null,
  pay text not null,
  status text not null default 'open', -- open, accepted, started, done, rated
  code text not null,
  stars int,
  note text
);
alter table requests add column if not exists service_id text;
alter table requests add column if not exists sector text;
alter table requests add column if not exists level int not null default 1;

-- 2) Komisyon bakiyesi
create table if not exists wallets(id text primary key, balance int not null default 0);

-- 3) Hizmet verenler. approved_level'i yalnızca siz (Supabase panelinden) değiştirirsiniz:
--    kimlik ve sicil kontrolü bitince Table Editor'da ilgili satırda approved_level'i yükseltin.
create table if not exists providers(
  id text primary key,
  created_at timestamptz default now(),
  name text not null,
  phone text,
  declared_level int not null default 1 check (declared_level between 1 and 4),
  approved_level int not null default 1 check (approved_level between 1 and 4)
);

-- 4) Hizmet verenin kendi seçtiği etiketler (hizmet id'leri uygulamadaki sözlükten gelir)
create table if not exists provider_services(
  provider_id text not null references providers(id) on delete cascade,
  service_id text not null,
  sector text not null,
  created_at timestamptz default now(),
  primary key (provider_id, service_id)
);

-- Etiket sınırı: sektör başına en fazla 10, toplam en fazla 40 (config.js ile aynı)
create or replace function check_tag_limits() returns trigger language plpgsql as $$
begin
  if (select count(*) from provider_services where provider_id = new.provider_id and sector = new.sector) >= 10 then
    raise exception 'Bu sektörde en fazla 10 hizmet seçebilirsiniz';
  end if;
  if (select count(*) from provider_services where provider_id = new.provider_id) >= 40 then
    raise exception 'Toplam en fazla 40 hizmet seçebilirsiniz';
  end if;
  return new;
end $$;
drop trigger if exists tag_limits on provider_services;
create trigger tag_limits before insert on provider_services for each row execute function check_tag_limits();

-- 5) Hizmet verenlerin önerdiği yeni anahtar kelimeler (siz onaylayınca sözlüğe eklenir)
create table if not exists keyword_suggestions(
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  provider_id text not null,
  service_id text not null,
  keyword text not null,
  status text not null default 'pending' -- pending, approved, rejected
);

-- 6) Hiçbir hizmete denk gelmeyen müşteri cümleleri (sözlüğü büyütmek için)
create table if not exists unmatched_queries(
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  text text not null
);

-- 7) Hizmet bazında puan (aynı kişinin farklı işlerdeki puanı ayrı tutulur)
create or replace view provider_service_stats as
  select provider as provider_id, service_id, count(*) as jobs, round(avg(stars)::numeric, 1) as avg_stars
  from requests where status = 'rated' and stars is not null
  group by provider, service_id;

-- 8) İş kabulü sunucuda denetlenir: etiket, onaylı seviye ve bakiye kontrolü tek adımda
create or replace function accept_request(p_request uuid, p_provider text) returns text
language plpgsql security definer set search_path = public as $$
declare r requests; p providers; bal int;
begin
  select * into r from requests where id = p_request for update;
  if r.id is null or r.status <> 'open' then return 'alindi'; end if;
  select * into p from providers where id = p_provider;
  if p.id is null then return 'kayit'; end if;
  if not exists (select 1 from provider_services where provider_id = p_provider and service_id = r.service_id) then
    return 'etiket';
  end if;
  if p.approved_level < r.level then return 'seviye'; end if;
  select balance into bal from wallets where id = p_provider;
  if coalesce(bal, 0) < 0 then return 'bakiye'; end if;
  update requests set provider = p_provider, status = 'accepted' where id = p_request;
  return 'ok';
end $$;

-- 9) Erişim kuralları
alter table requests enable row level security;
alter table wallets enable row level security;
alter table providers enable row level security;
alter table provider_services enable row level security;
alter table keyword_suggestions enable row level security;
alter table unmatched_queries enable row level security;

drop policy if exists "pilot all" on requests;
drop policy if exists "pilot all" on wallets;
drop policy if exists "pilot all" on providers;
drop policy if exists "pilot all" on provider_services;
drop policy if exists "pilot all" on keyword_suggestions;
drop policy if exists "pilot all" on unmatched_queries;
-- PİLOT/TEST İÇİN AÇIK İZİN. Gerçek kullanıma geçmeden giriş sistemi ve kişiye özel kurallar eklenmeli.
create policy "pilot all" on requests for all using (true) with check (true);
create policy "pilot all" on wallets for all using (true) with check (true);
create policy "pilot all" on providers for all using (true) with check (true);
create policy "pilot all" on provider_services for all using (true) with check (true);
create policy "pilot all" on keyword_suggestions for all using (true) with check (true);
create policy "pilot all" on unmatched_queries for all using (true) with check (true);

-- Uygulama onaylı seviyeyi ve işi kime verildiğini kendisi değiştiremez:
revoke insert, update on providers from anon;
grant insert (id, name, phone, declared_level) on providers to anon;
grant update (name, phone, declared_level) on providers to anon;
revoke update on requests from anon;
grant update (status, stars, note) on requests to anon;
grant execute on function accept_request(uuid, text) to anon;
