"""Okindo: yapay zeka kullanmadan, kelime eşleştirmeyle hizmet ve sektör tahmini."""
import json, re, math, os
from collections import Counter

def norm(s):
    s = s.replace("İ", "i").replace("I", "ı").lower()
    s = s.translate(str.maketrans("çğıöşüâîû", "cgiosuaiu"))
    return re.sub(r"[^a-z0-9 ]", " ", s)

def _y(s):
    """Ünsüz yumuşaması: çocuğ→çocuk, hasad→hasat, kitab→kitap."""
    if s and s[-1] in "gdb":
        return s[:-1] + {"g": "k", "d": "t", "b": "p"}[s[-1]]
    return s

def kok(w):
    """Anahtar kelime tarafı: 3-4 harfliyse kendisi, daha uzunsa ilk 5 harf."""
    return _y(w if len(w) <= 4 else w[:5])

def sorgu_kokleri(w):
    """Kullanıcı kelimesi ek alabilir: hem 4 hem 5 harflik kök adayını dene."""
    return {_y(w[:4]), _y(w[:5])} if len(w) >= 5 else {_y(w)}

DUR = set(norm("""lazım olsun biri biriyle arıyorum arıyoruz güvenilir yapacak yapmak yapsın gerekiyor istiyorum
için ile ben bir çok daha ve veya ama bu şu o bana bizim benim var yok mı mi mu mü de da ki gibi
olacak olan almak etmek edecek eder yardım yardımcı rica lütfen acaba nasıl nerede kim""").split())

ESIK = 2.6   # bunun altı "anlaşılamadı" sayılır

class Eslestirici:
    def __init__(self, yol=None):
        yol = yol or os.path.join(os.path.dirname(os.path.abspath(__file__)), "okindo_hizmet_sozlugu.json")
        self.h = json.load(open(yol, encoding="utf-8"))
        df = Counter()
        self.kokler = []
        self.baslik = []                                   # hizmet adındaki kökler
        for x in self.h:
            self.baslik.append({kok(w) for w in norm(x["hizmet"]).split() if len(w) > 2 and w not in DUR})
        for x in self.h:
            ks = set()
            for k in x["anahtar"] + [x["hizmet"]]:
                for w in norm(k).split():
                    if len(w) > 2 and w not in DUR: ks.add(kok(w))
            self.kokler.append(ks)
            df.update(ks)
        n = len(self.h)
        self.idf = {k: math.log(1 + n / v) for k, v in df.items()}

    def tahmin(self, cumle, top=3):
        nc = norm(cumle)
        q = set()
        for w in nc.split():
            if len(w) > 2 and w not in DUR: q |= sorgu_kokleri(w)
        sonuc = []
        for x, ks, bs in zip(self.h, self.kokler, self.baslik):
            p = sum(self.idf[k] for k in q & ks)
            p += 4.0 * len(q & bs) / max(1, len(bs))        # başlığın ne kadarı sorguyla örtüşüyor (kısa, net başlık kazanır)
            for ifade in x["anahtar"]:                      # çok kelimeli ifade bonusu
                f = norm(ifade).strip()
                if " " in f and f in nc: p += 2.5
            if p > 0: sonuc.append((p, x))
        sonuc.sort(key=lambda t: -t[0])
        if not sonuc or sonuc[0][0] < ESIK:                # yeterince güçlü eşleşme yok
            return {"sektor": None, "hizmetler": []}
        hizmetler = [(x["hizmet"], x["sektor"], round(p, 1)) for p, x in sonuc[:top]]
        return {"sektor": sonuc[0][1]["sektor"], "hizmetler": hizmetler}

if __name__ == "__main__":
    E = Eslestirici()
    TEST = [
     ("çocuğumu okuldan alacak güvenilir biri","Aile ve çocuk"),
     ("babamı hastaneye götürmem lazım yanında biri olsun","Yaşlı, hasta ve engelli"),
     ("tapuda sıra bekleyecek biri arıyorum","Resmi işler ve finans"),
     ("arabamı kullanacak şoför lazım","Ulaşım ve araç"),
     ("evde usta gelecek ben işteyim","Ev ve eşya"),
     ("kedim için online veteriner",{"Online uzman","Evcil hayvan"}),
     ("annemi ziyaret edip nasıl olduğunu bildirsin",{"Yaşlı, hasta ve engelli","Yurt dışındaki yakınlar"}),
     ("ilaçlarımı eczaneden getirsin",{"Günlük işler ve alışveriş","Yaşlı, hasta ve engelli"}),
     ("misafirimi havalimanından karşılayacak biri","Ulaşım ve araç"),
     ("telefonuma uygulamaları kuracak biri","Dijital destek"),
     ("köpeğimi akşam gezdirecek biri","Evcil hayvan"),
     ("düğün için davetiye dağıtacak biri","Etkinlik ve özel gün"),
     ("tatilde çiçeklerimi sulasın",{"Ev ve eşya","Taşınma ve emlak","Evcil hayvan","Yurt dışındaki yakınlar"}),
     ("babaannemin mezarına bakım yapılacak",{"Yurt dışındaki yakınlar","Etkinlik ve özel gün"}),
     ("evi taşıyacağım koli toplayacak biri",{"Taşınma ve emlak","Ev ve eşya"}),
     ("yurt dışından annemin yanına gidecek biri","Yurt dışındaki yakınlar"),
     ("fındık hasadında yardım edecek biri","Tarım ve köy"),
     ("mutfakta yemek yapacak biri","Yemek ve mutfak"),
     ("diyetisyenle görüşmek istiyorum","Online uzman"),
     ("kuaförde randevu",{"Güzellik ve kişisel bakım","Günlük işler ve alışveriş"}),
    ]
    ok = 0
    for t, d in TEST:
        r = E.tahmin(t)
        kabul = d if isinstance(d, set) else {d}
        good = (r["sektor"] in kabul) or (d == "Hiçbiri" and not r["hizmetler"])
        ok += good
        print("OK  " if good else "HATA", t, "→", r["sektor"], "|", r["hizmetler"][0][0] if r["hizmetler"] else "-")
    print(f"\nSektör doğruluğu: {ok}/{len(TEST)}")
