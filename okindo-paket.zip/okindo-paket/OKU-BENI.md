# Okindo paketi (26 Ekim 2026)

**android-uygulama/** Android uygulamasının kaynağı. Kurulum ve APK alma adımları içindeki README.md'de.
  - `data/hizmetler.json` 50 sektör, 2.648 hizmet, anahtar kelimeleriyle.
  - `lib/eslestirici.js` yapay zekasız kelime eşleştirici (Python sürümüyle birebir aynı sonuç verir).
  - `schema.sql` veritabanı: talepler, hizmet verenler, etiketler, seviye kilidi, kelime önerileri.

**veri/** Aynı sözlüğün JSON hâli ve Python eşleştiricisi (bilgisayarda deneme ve sözlük güncellemek için).

**belgeler/okindo_tum_veriler.docx** Sektör sayıları, pilot risk tablosu, eşleştirme mantığı, hizmet veren etiketleri ve tam sözlük.

**tasarim/** Logo ve ilk tıklanabilir tasarım demosu (tarayıcıda açılır).

Ana çalışma dokümanı (iş modeli, kurallar, yol haritası): https://claude.ai/artifact/3N783KoNFSnRRYtvVjbBmK
